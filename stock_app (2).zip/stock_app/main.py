import os
import asyncio
import yfinance as yf
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime
from dotenv import load_dotenv
from groq import AsyncGroq

load_dotenv()

app = FastAPI()

# --- CONFIGURATION ---
HF_API_TOKEN = os.getenv("HF_API_TOKEN")
GROQ_API_KEY = os.getenv("GROQ_API_KEY") 
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}

# --- DATABASE ---
client = AsyncIOMotorClient(MONGO_URI)
db = client.stock_app
collection = db.history

# --- CLIENTS ---
# 1. Groq Client
groq_client = AsyncGroq(api_key=GROQ_API_KEY)

# 2. Hugging Face URL (Sentiment)
URL_SENTIMENT = "https://router.huggingface.co/hf-inference/models/ProsusAI/finbert"

class PredictionResponse(BaseModel):
    ticker: str
    current_price: float
    recommendation: str
    sentiment_summary: str
    explanation: str
    timestamp: str
    price_history: list[float]
    history_dates: list[str]

# --- HELPER: SENTIMENT (Hugging Face) ---
async def get_sentiment_score(headlines):
    total_score = 0
    count = 0
    if not headlines: headlines = ["Company reports steady outlook."]

    async with httpx.AsyncClient() as client:
        for headline in headlines[:3]:
            try:
                response = await client.post(URL_SENTIMENT, headers=headers, json={"inputs": str(headline)[:512]}, timeout=10.0)
                
                if response.status_code != 200: continue
                
                data = response.json()
                if isinstance(data, list) and isinstance(data[0], list): data = data[0]
                if not data or not isinstance(data, list): continue

                top = max(data, key=lambda x: x.get('score', 0))
                if top['label'] == 'positive': total_score += top['score']
                elif top['label'] == 'negative': total_score -= top['score']
                count += 1
            except Exception:
                continue

    if count == 0: return 0
    return total_score / count

# --- HELPER: EXPLANATION (Groq) ---
async def get_llm_explanation(ticker, headlines, recommendation, score):
    print("DEBUG: Generating explanation with Groq...")
    
    if not headlines:
        news_text = "No specific news found."
    else:
        news_text = ". ".join([h[:100] for h in headlines[:3]])
    
    try:
        # --- FIX IS HERE ---
        # We switched to 'llama-3.1-8b-instant' which is the current fast/free model.
        completion = await groq_client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": "You are a financial analyst. Write a 2-sentence explanation for the stock recommendation."
                },
                {
                    "role": "user",
                    "content": f"Stock: {ticker}\nRec: {recommendation} (Score: {score:.2f})\nNews: {news_text}\nWhy?"
                }
            ],
            model="llama-3.1-8b-instant", 
            temperature=0.5,
            max_tokens=100,
        )
        return completion.choices[0].message.content.strip()

    except Exception as e:
        print(f"DEBUG: Groq Error -> {e}")
        # Final Fallback
        if recommendation == "BUY":
            return f"Strong buy signals for {ticker} supported by positive market sentiment."
        elif recommendation == "SELL":
            return f"Caution advised for {ticker} due to negative technical indicators."
        return f"Market outlook for {ticker} remains neutral."

# --- ROUTES ---
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def read_root():
    return FileResponse('static/index.html')

@app.get("/history")
async def get_history():
    try:
        cursor = collection.find({}).sort("timestamp", -1).limit(10)
        history = await cursor.to_list(length=10)
        for doc in history: doc["_id"] = str(doc["_id"])
        return history
    except Exception:
        return []

@app.get("/predict/{ticker}", response_model=PredictionResponse)
async def predict(ticker: str):
    ticker = ticker.upper()
    print(f"\n--- NEW REQUEST: {ticker} ---")
    
    stock = yf.Ticker(ticker)
    
    # 1. Fetch History
    loop = asyncio.get_event_loop()
    try:
        hist = await loop.run_in_executor(None, lambda: stock.history(period="1mo"))
    except Exception:
        raise HTTPException(status_code=404, detail="Ticker not found")

    if hist.empty:
        raise HTTPException(status_code=404, detail="Ticker not found")

    current_price = hist['Close'].iloc[-1]
    price_history = hist['Close'].tolist()
    history_dates = hist.index.strftime('%b %d').tolist()

    # 2. Get News
    headlines = []
    try:
        news_data = stock.news
        if news_data:
            for item in news_data:
                title = item.get('content', {}).get('title') or item.get('title')
                if title: headlines.append(title)
    except Exception:
        pass

    # 3. Analyze Sentiment
    sentiment_score = await get_sentiment_score(headlines)
    
    # 4. Recommendation
    rec = "HOLD"
    if sentiment_score > 0.15: rec = "BUY"
    elif sentiment_score < -0.15: rec = "SELL"
    
    # 5. LLM Explanation
    explanation = await get_llm_explanation(ticker, headlines, rec, sentiment_score)

    result = {
        "ticker": ticker,
        "current_price": round(current_price, 2),
        "recommendation": rec,
        "sentiment_summary": f"{sentiment_score:.4f}",
        "explanation": explanation,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "price_history": [round(p, 2) for p in price_history],
        "history_dates": history_dates
    }

    await collection.insert_one(result.copy())
    return result